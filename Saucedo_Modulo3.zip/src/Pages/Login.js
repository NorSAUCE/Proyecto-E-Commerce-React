import React from "react";
import Input from "../Components/Input"
import { useForm } from "react-hook-form";
import {Form,Button} from 'react-bootstrap'
import firebase from "../Config/firebase"
function Login(){
    const { register, handleSubmit, formState: { errors } } = useForm();
    const onSubmit=async (data)=>{
    console.log("Form",data)
    try{
      const responseUser=await firebase.auth().signInWithEmailAndPassword(data.email,data.password)
      console.log("responseUser",responseUser)
    }catch(e){
        console.log(e)
    }
   
    }
    return(
        <div>
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Input label="Email" type="email" register={{...register("email",{ required: true })}} />
                {errors.email && <span>El campo Email es obligatorio</span>}
                <Input label="Contraseña" type="password"register={{...register("password", { required: true })}}  />
                {errors.password && <span>El campo Contraseña es obligatorio</span>}
                 <Button variant="primary" type="submit">
                  Ingresar
                </Button>
            </Form>
        </div>
    )
}
export default Login