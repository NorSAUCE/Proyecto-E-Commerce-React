import React,{useState,useEffect} from "react"
import {useParams} from "react-router-dom"
import {getByIdProductos} from "../Services/ProductosService"
function Detalle(){
    const{id}=useParams()
    const[producto,setProducto]=useState({})
    const[loading,setLoading]=useState(true) 
   useEffect(
         ()=>{
            const request = async ()=>{
                
                try{
                    setLoading(true)
                    const response = await getByIdProductos(id)
                setProducto(response.data)
                console.log(response)
                setLoading(false)
                }catch(e){
                    console.log(e)
                    setLoading(false)
                }
                
            }
            request()
         },
         [id]
   )
    if(loading){
        return(
            <div>
                Cargando ...
            </div>
        )
        
    }else{
    return(
        <>
       <div>Nombre:{producto.title}</div>
       <div>Precio:{producto.price}</div>
       <div><img src={producto.pictures[0].url}></img></div>
       <button>Comprar</button>
       </>
    )
    }
}

export default Detalle;