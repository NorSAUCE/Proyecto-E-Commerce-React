import React from "react";
import {Link} from "react-router-dom"
const styles ={
    img:{
        width:'100px'
    }
}
function Producto(props){
    const {nombre,thumbnail,id} = props
    return(
            <div>
               <p>Nombre: {nombre}</p>
               <img src={thumbnail} style={styles.img}></img> 
               <p><Link to={'/producto/'+id}>Ver Detalle</Link></p>     
            </div>
    )
}
export default Producto;