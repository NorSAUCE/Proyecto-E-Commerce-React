import React from 'react'
import Home from '../Pages/Home'
import Formulario from '../Pages/Formulario'
import Detalle from '../Pages/Detalle'
import Login from '../Pages/Login'
import{
  Routes,
  Route
}from "react-router-dom"
function Public() {
  return(
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/formulario' element={<Formulario />} />
        <Route path='/login' element={<Login/>}/>
        <Route path='/producto/:id' element={<Detalle />} />
      </Routes>
  )
}

export default Public;