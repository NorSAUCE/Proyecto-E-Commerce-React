export const loginMessage={
    "auth/user-not-found":"El e-mail no es correcto",
    "auth/wrong-password":"Contraseña incorrecta"
}
export const registroMessage={
    "auth/email-already-in-use":"El email ya existe",
    "auth/weak-password":"La contraseña debe tener un minimo de 6 caracteres"
}