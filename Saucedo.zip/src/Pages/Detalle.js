import React,{useState,useEffect} from "react"
import {useParams} from "react-router-dom"
import {getByIdProductos} from "../Services/ProductosService"
import {Loading} from "../Components/Loading"
function Detalle(){
    const{id}=useParams()
    const[producto,setProducto]=useState({})
    const[loading,setLoading]=useState(true) 
   useEffect(
         ()=>{
            const request = async ()=>{
                
                try{
                    setLoading(true)
                    const response = await getByIdProductos(id)
                setProducto(response.data)
                console.log(response)
                setLoading(false)
                }catch(e){
                    console.log(e)
                    setLoading(false)
                }
                
            }
            request()
         },
         [id]
   )
   return(
    <Loading loading={loading}>
        <div>Nombre:{producto.title}</div>
       <div>Precio:{producto.price}</div>
       <div>{producto.pictures.map(pictures=><img src={pictures.url} alt="imagen"/>)}</div>
    </Loading>
)
}

export default Detalle;